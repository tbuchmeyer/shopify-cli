# Installation

The installation guide can be found here: https://shopify.dev/apps/tools/cli/cli-2#installing-shopify-cli-2-x

# frozen_string_literal: true
module ShopifyCLI
  module Theme
    class DevServer
      # Errors
      class Error < StandardError; end
    end
  end
end

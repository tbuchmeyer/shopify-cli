module ShopifyCLI
  module GitHub
    autoload :IssueURLGenerator, "shopify_cli/github/issue_url_generator"
  end
end

require "shopify_cli"

module ShopifyCLI
  module CommandOptions
    autoload :CommandServeOptions, "shopify_cli/command_options/command_serve_options"
  end
end

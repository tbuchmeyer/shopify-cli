module ShopifyCLI
  module Helpers
    autoload :Haikunator, "shopify_cli/helpers/haikunator"
  end
end

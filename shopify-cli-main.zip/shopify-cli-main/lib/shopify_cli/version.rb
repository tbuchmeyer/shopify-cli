module ShopifyCLI
  VERSION = "2.36.0"
end

module ShopifyCLI
  module Resources
    autoload :EnvFile, "shopify_cli/resources/env_file"
  end
end
